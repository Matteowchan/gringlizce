# Yazı Pratiği Wizard v2 — Unified (IB + TOEFL)

Tek wizard, sınav + text type dropdown'lı. Önceki tüm Yazı Pratiği paketlerinin yerini alır.

## Değişiklikler

**Yeni:**
- `yazi-pratigi.html` — Tek wizard (IB English B + TOEFL Writing aktif, IELTS dropdown'da "Yakında")

**Silinen:**
- `ib-yazi-pratigi.html` (eski hub)
- `ib-yazi-pratigi-blog.html` (eski redirect)
- `ib-yazi-pratigi-wizard.html` (eski wizard)

**Güncellenen (169 sayfa):**
- Navbar: "IB Yazı Pratiği" → "Yazı Pratiği"
- URL: `ib-yazi-pratigi.html` → `yazi-pratigi.html`

## Yükleme

### Adım 1: SQL'i çalıştır (Supabase SQL Editor)

`01_toefl_seed.sql` dosyasını Supabase SQL Editor'a yapıştır ve çalıştır.

**Ne yapar:**
- 2 yeni text type ekler: `toefl-email`, `toefl-academic-discussion`
- 10 örnek prompt seed eder (5 email + 5 academic discussion)
- Doğrulama SELECT'leri en altta sonuçları gösterir

**Beklenen çıktı:**
```
TEXT TYPES | toefl-email                | Email                | true | false
TEXT TYPES | toefl-academic-discussion  | Academic Discussion  | true | false
PROMPTS    | toefl-email                | 5
PROMPTS    | toefl-academic-discussion  | 5
```

### Adım 2: HTML dosyalarını yükle

GitHub web → repo → "Add files via upload" → zip içindeki tüm dosyaları sürükle bırak (170 HTML) → commit.

**Önemli:** Eski 3 dosyayı (`ib-yazi-pratigi*.html`) GitHub'dan **manuel sil** çünkü zip overwrite eder ama silmez:
1. GitHub'da repo'ya gir
2. `ib-yazi-pratigi.html` üzerine tıkla → "Delete file" (en sağ üst, çöp kovası ikonu)
3. Aynısını `ib-yazi-pratigi-blog.html` ve `ib-yazi-pratigi-wizard.html` için yap
4. Commit

Commit mesajı:
```
feat: Unified Yazı Pratiği wizard — IB + TOEFL with dropdowns

- New: yazi-pratigi.html (single wizard with exam + text type dropdowns)
- Removed: ib-yazi-pratigi.html, -blog.html, -wizard.html (consolidated)
- 169 pages updated: navbar "IB Yazı Pratiği" → "Yazı Pratiği"
- TOEFL Writing 2026 format: Email (80-120w, 9pt rubric) + Academic Discussion (100-150w, 15pt rubric)
- IELTS dropdown coming soon
```

## Test Akışı

1. `https://gringlizce.com/yazi-pratigi.html` aç
2. Üstte 2 dropdown göreceksin:
   - **Sınav:** IB English B (default), TOEFL Writing, IELTS (Yakında - disabled)
   - **Text Type:** IB seçiliyken Blog Post, TOEFL seçince Email + Academic Discussion
3. **Sınav değiştir** → text type dropdown otomatik yenilenir, ilk aktif text type seçilir
4. **Text type değiştir** → rubric, format guide, prompt otomatik yenilenir
5. **IB seçince** SL/HL toggle görünür, TOEFL/IELTS'te gizlenir
6. URL otomatik güncellenir: `?exam=toefl&type=toefl-email`
7. Yazı yaz → "Değerlendir" → ~5-10sn sonra feedback
8. Quota pill her başarılı evaluate'da güncellenir

## Rubric Sistemleri

| Sınav | Text Type | Max Puan | Kriterler |
|---|---|---|---|
| IB English B | Blog Post | 30 | A (12) + B (12) + C (6) |
| TOEFL | Email | 9 | Task Response + Tone & Register + Language Use (3+3+3) |
| TOEFL | Academic Discussion | 15 | Task Response + Development + Language Use (5+5+5) |

## Bilinen Durum

- **IB:** 1 aktif text type (Blog), 5 prompt + 10 "yakında"
- **TOEFL:** 2 aktif text type (Email, Academic Discussion), her birinde 5 prompt
- **IELTS:** Dropdown'da disabled (Yakında etiketli). Sonraki paketle açılacak.

## Sonraki Adımlar

1. **IELTS entegrasyonu:** writing_text_types ve writing_prompts'a IELTS Task 1 Academic + Task 2 Academic ekle, dropdown'da aktif et.
2. **IELTS deneme sayfalarına "Gri ile değerlendir" butonu:** `ielts-deneme-writing.html` ve `ielts-bolum-calisma.html`'e inline buton.
3. **IB diğer text type'lar:** Article, Speech, Letter/Email, Diary, Brochure, Review, Report, News Report, Interview, Social Media için rubric+format+prompt seed.
4. **Prompt havuzu genişlet:** Şu an her text type'ta 5 prompt. 20-30'a çıkarmak için ayrı SQL veya AI batch generation.
5. **Submission geçmişi:** `panelim.html`'de kullanıcı eski yazılarını görsün.

Hangisini istersin söyle.
