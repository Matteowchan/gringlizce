-- =============================================================
-- TOEFL Writing Practice — Email + Academic Discussion seed
-- =============================================================
-- Bu SQL TOEFL Writing 2026 formatı için 2 text type ve toplam
-- 10 örnek prompt ekler (5 email + 5 academic discussion).
-- =============================================================

-- ============ TEXT TYPES ============

INSERT INTO writing_text_types (
  id, exam, text_type, display_name, sort_order, is_active, is_coming_soon,
  word_count_sl_min, word_count_sl_max,
  word_count_hl_min, word_count_hl_max,
  rubric_json, format_guide_json
) VALUES
(
  'toefl-email',
  'toefl',
  'email',
  'Email',
  20,
  true,
  false,
  80, 120,
  NULL, NULL,
  '{
    "total_max": 9,
    "criteria": [
      {
        "label": "Task Response",
        "max_points": 3,
        "description": "Soruyu doğru anlamış, istenen tüm bilgileri sağlamış. Email''in amacı net şekilde yerine getirilmiş."
      },
      {
        "label": "Tone & Register",
        "max_points": 3,
        "description": "Duruma uygun ton (resmi veya yarı resmi). Doğru selamlama ve kapanış. Saygılı, profesyonel ifade."
      },
      {
        "label": "Language Use",
        "max_points": 3,
        "description": "Gramer doğruluğu, kelime seçimi, cümle akışı. Bağlaçlar ve akıcılık. Yazım ve noktalama."
      }
    ]
  }'::jsonb,
  '[
    {
      "title": "1. Selamlama",
      "content": "Resmi: Dear Professor [Surname], / Dear Dr. [Surname], / Yarı resmi: Hello [Name], / Hi [Name],"
    },
    {
      "title": "2. Açılış cümlesi",
      "content": "Email''in amacını 1-2 cümleyle direkt belirt. Önceki yazışmaya atıf yap: Thank you for your email regarding... / I am writing in response to..."
    },
    {
      "title": "3. Ana içerik",
      "content": "Sorulanlara cevap ver. Eğer karar veriliyorsa kararı net söyle ve kısa gerekçe sun. Eğer bilgi isteniyorsa sırayla sağla. 2-4 cümle yeterli."
    },
    {
      "title": "4. Kapanış cümlesi",
      "content": "Bir sonraki adımı belirt veya teşekkür et: Please let me know if you need anything else. / Thank you for your time and consideration."
    },
    {
      "title": "5. İmza",
      "content": "Resmi: Sincerely, / Best regards, / Yarı resmi: Best, / Thanks, sonrasında ad-soyad."
    },
    {
      "title": "Uzunluk hedefi",
      "content": "80-120 kelime. Çok kısa yazma (eksik bilgi riski), çok uzun yazma (gereksiz detay riski)."
    }
  ]'::jsonb
),
(
  'toefl-academic-discussion',
  'toefl',
  'academic_discussion',
  'Academic Discussion',
  21,
  true,
  false,
  100, 150,
  NULL, NULL,
  '{
    "total_max": 15,
    "criteria": [
      {
        "label": "Task Response",
        "max_points": 5,
        "description": "Profesörün sorusuna doğrudan cevap verme. Net pozisyon. Sınıf arkadaşlarının görüşlerine atıf veya ilişkilendirme."
      },
      {
        "label": "Development & Support",
        "max_points": 5,
        "description": "Açıklayıcı detaylar, somut örnekler, mantıklı gerekçelendirme. Yüzeysel iddiadan kaçınma. Kendi pozisyonunu destekleyici fikirler."
      },
      {
        "label": "Language Use",
        "max_points": 5,
        "description": "Gramer çeşitliliği ve doğruluğu. Akademik kelime seçimi. Bağlaçlar ve geçişler. Cümle yapısı çeşitliliği."
      }
    ]
  }'::jsonb,
  '[
    {
      "title": "1. Pozisyon (1 cümle)",
      "content": "İlk cümlede net görüşünü belirt. Belirsiz başlama. Örnek: In my view, ... / I firmly believe that... / Personally, I think..."
    },
    {
      "title": "2. Sınıf arkadaşlarına atıf",
      "content": "En az birinin görüşüne atıf yap (uyum veya karşıt). Örnek: While I agree with Susan that..., I would argue... / Building on Mark''s point about..."
    },
    {
      "title": "3. Gerekçe (2-3 cümle)",
      "content": "Görüşünü neden savunduğunu mantıkla açıkla. Mekanizma sun: çünkü X olduğunda Y olur, bu da Z''ye yol açar."
    },
    {
      "title": "4. Somut örnek veya destek",
      "content": "Kişisel deneyim, ülke örneği, akademik referans veya hipotetik senaryo. Soyut kalmayın."
    },
    {
      "title": "5. Sonuç veya genişletme (opsiyonel)",
      "content": "Son cümlede pozisyonunu hatırlat veya konuyu hafifçe genişlet. Yeni argüman açma."
    },
    {
      "title": "Uzunluk hedefi",
      "content": "100-150 kelime. Tartışma forumu mantığıyla yaz. Akademik ama doğal."
    }
  ]'::jsonb
)
ON CONFLICT (id) DO UPDATE SET
  display_name = EXCLUDED.display_name,
  sort_order = EXCLUDED.sort_order,
  is_active = EXCLUDED.is_active,
  is_coming_soon = EXCLUDED.is_coming_soon,
  word_count_sl_min = EXCLUDED.word_count_sl_min,
  word_count_sl_max = EXCLUDED.word_count_sl_max,
  rubric_json = EXCLUDED.rubric_json,
  format_guide_json = EXCLUDED.format_guide_json;

-- ============ PROMPTS: TOEFL EMAIL ============

INSERT INTO writing_prompts (text_type_id, level, title, prompt, word_count_min, word_count_max, difficulty) VALUES
(
  'toefl-email',
  NULL,
  'Course Schedule Conflict',
  'Read the following email from your professor and respond appropriately.

From: Professor Anderson
Subject: Important — Office Hours Change Next Week

Dear Students,

Due to a conference I will be attending next week, my regular office hours on Wednesday afternoon will be cancelled. I am offering two alternative slots: Tuesday from 10-11 AM or Thursday from 2-3 PM. Please let me know which time works better for you, and briefly mention what you would like to discuss so I can prepare in advance. If neither option works, suggest an alternative.

Best regards,
Prof. Anderson

Write a reply to Professor Anderson. Indicate which time you prefer, explain what you would like to discuss, and address any other points raised in the email.',
  80, 120, 'medium'
),
(
  'toefl-email',
  NULL,
  'Apartment Maintenance Request',
  'Read the following email from your apartment building manager and respond appropriately.

From: Ms. Carter, Building Manager
Subject: Maintenance Inspection Schedule

Dear Resident,

We will be conducting routine maintenance inspections in all units next week. Inspectors need access between 9 AM and 5 PM on either Monday or Wednesday. Please reply with your preferred day, confirm whether you will be home or grant permission for entry in your absence, and mention any specific maintenance issues that need attention in your unit.

Thank you,
Ms. Carter

Write a reply confirming your preferred day, addressing the access question, and mentioning any maintenance concerns you have.',
  80, 120, 'medium'
),
(
  'toefl-email',
  NULL,
  'Missed Class Follow-up',
  'Read the following email from your classmate and respond appropriately.

From: Alex Wong
Subject: Notes from yesterday''s lecture?

Hi,

I had to miss yesterday''s economics lecture because of a doctor''s appointment. Would you mind sharing your notes with me? Also, did the professor mention anything about the upcoming midterm — specifically the format or topics covered? I want to make sure I don''t fall behind. If you have time this weekend, maybe we could meet to go over the material together.

Thanks a lot,
Alex

Write a reply to Alex. Respond to all the questions raised and propose a concrete plan if you can meet.',
  80, 120, 'easy'
),
(
  'toefl-email',
  NULL,
  'Club Membership Inquiry',
  'Read the following email and respond appropriately.

From: David Park, President of International Students Club
Subject: Welcome to our club — next steps

Dear New Member,

Thank you for expressing interest in joining the International Students Club. To complete your registration, we need a few things: confirmation that you can attend our weekly Friday meetings at 6 PM, your area of interest (cultural events, language exchange, or community service), and whether you would like to volunteer for our upcoming welcome event next month.

Looking forward to having you,
David Park

Reply to David with the information he requested. Be specific in your responses.',
  80, 120, 'easy'
),
(
  'toefl-email',
  NULL,
  'Study Abroad Program Question',
  'Read the following email from a university advisor and respond appropriately.

From: Dr. Mitchell, Study Abroad Office
Subject: Re: Your study abroad application

Dear Applicant,

Thank you for your interest in our exchange program in Berlin. Before I can process your application, I need clarification on a few points. First, which semester are you planning to attend (Fall or Spring)? Second, what is your primary academic goal for this program — language acquisition, specific coursework, or research opportunities? Finally, do you have any housing preferences I should note?

I look forward to your response,
Dr. Mitchell

Write a reply addressing all three of Dr. Mitchell''s questions with specific information.',
  80, 120, 'medium'
)
ON CONFLICT DO NOTHING;

-- ============ PROMPTS: TOEFL ACADEMIC DISCUSSION ============

INSERT INTO writing_prompts (text_type_id, level, title, prompt, word_count_min, word_count_max, difficulty) VALUES
(
  'toefl-academic-discussion',
  NULL,
  'Technology and Society',
  'Your professor is teaching a class on sociology. You must post a written response to your professor''s question.

In your response you should:
- Express and support your opinion
- Make a contribution to the discussion

An effective response will contain at least 100 words.

Dr. Patel:
This week we are examining how technology shapes social behavior. Some argue that smartphones have weakened face-to-face communication, while others claim that technology has made us more connected than ever. In your opinion, has smartphone technology had a more positive or more negative impact on the quality of human relationships? Why?

Maria:
I think smartphones have damaged real connection. People sit at dinner tables staring at their screens instead of talking. My own family barely speaks during meals anymore.

Jamal:
I disagree. Without my phone I could never stay in touch with my grandparents back home or my friends who moved abroad. Technology expands relationships rather than limiting them.

Now write your response (100-150 words).',
  100, 150, 'medium'
),
(
  'toefl-academic-discussion',
  NULL,
  'Education and Specialization',
  'Your professor is teaching a class on education policy. You must post a written response to your professor''s question.

In your response you should:
- Express and support your opinion
- Make a contribution to the discussion

An effective response will contain at least 100 words.

Professor Chen:
A debate has emerged about how universities should structure their programs. Some believe students should specialize early to develop deep expertise in one field. Others argue that a broad, liberal education across multiple disciplines better prepares students for the modern workforce. Which approach do you believe is more beneficial for university students today?

Sara:
Early specialization is essential. Companies want experts, not generalists. Spending four years on broad subjects wastes time you could use mastering a profession.

Daniel:
A broad education teaches you how to think, not just what to think. Jobs change so quickly now that flexibility matters more than narrow expertise.

Now write your response (100-150 words).',
  100, 150, 'medium'
),
(
  'toefl-academic-discussion',
  NULL,
  'Government and Environment',
  'Your professor is teaching a class on environmental policy. You must post a written response to your professor''s question.

In your response you should:
- Express and support your opinion
- Make a contribution to the discussion

An effective response will contain at least 100 words.

Dr. Roberts:
Climate change requires action, but who should bear the primary responsibility for reducing emissions: governments through regulation, or individuals through personal choices? Which approach do you believe will be more effective?

Linda:
Individual action matters but is too small in scale. Only governments can mandate the systemic changes needed — industry regulations, public transit, renewable energy investment.

Omar:
Government policies fail when citizens don''t support them. Real change starts with individual habits that shift cultural norms, which then pressure governments to act.

Now write your response (100-150 words).',
  100, 150, 'hard'
),
(
  'toefl-academic-discussion',
  NULL,
  'Workplace and Productivity',
  'Your professor is teaching a class on business management. You must post a written response to your professor''s question.

In your response you should:
- Express and support your opinion
- Make a contribution to the discussion

An effective response will contain at least 100 words.

Professor Williams:
Many companies are debating whether to require employees to return to the office full-time, allow fully remote work, or adopt a hybrid model. Which model do you believe is best for both employee satisfaction and company productivity, and why?

Kenji:
Hybrid is the obvious answer. Employees get flexibility for focused work at home and collaboration in the office. It balances both needs.

Aisha:
Full remote is the future. Office space is expensive, commutes waste time, and trust-based work culture produces better results than constant supervision.

Now write your response (100-150 words).',
  100, 150, 'medium'
),
(
  'toefl-academic-discussion',
  NULL,
  'Leadership Qualities',
  'Your professor is teaching a class on leadership studies. You must post a written response to your professor''s question.

In your response you should:
- Express and support your opinion
- Make a contribution to the discussion

An effective response will contain at least 100 words.

Dr. Foster:
What do you believe is the single most important quality of an effective leader: the ability to make quick decisions, the willingness to listen to others, the capacity to inspire trust, or strong communication skills? Defend your choice.

Eric:
Trust is the foundation. Without it, no decision is followed wholeheartedly and no communication is believed. Everything else stems from trust.

Hannah:
Decision-making is what separates leaders from followers. A leader who hesitates loses opportunities and the respect of the team.

Now write your response (100-150 words).',
  100, 150, 'medium'
)
ON CONFLICT DO NOTHING;

-- ============ Doğrulama ============
SELECT 'TEXT TYPES' as kind, id, display_name, is_active, is_coming_soon
FROM writing_text_types WHERE exam = 'toefl' ORDER BY sort_order;

SELECT 'PROMPTS' as kind, text_type_id, count(*) as adet
FROM writing_prompts WHERE text_type_id LIKE 'toefl-%' GROUP BY text_type_id;
